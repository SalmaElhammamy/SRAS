import express from "express"
import { Fetch,Create,Update,DeleteUser } from "../controller/CameraController.js"
// import { Fetch2,Create2,Update2,DeleteUser2 } from "../controller/SettingsController.js"

const route=express.Router();

route.post("/create",Create);
route.get("/getallusers",Fetch);
route.put("/update/:id", Update);
route.delete("/delete/:id",DeleteUser);



export default route;