import express from "express"
import { Fetch1,Create1,Update1,DeleteUser1 } from "../controller/settingsController.js"
// import { Fetch2,Create2,Update2,DeleteUser2 } from "../controller/SettingsController.js"

const route1=express.Router();

route1.post("/create1",Create1);
route1.get("/getallusers1",Fetch1);
route1.put("/update1/:id", Update1);
route1.delete("/delete1/:id",DeleteUser1);



export default route1;