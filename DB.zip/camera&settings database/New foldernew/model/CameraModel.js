import mongoose from "mongoose";

const UserSchema= new mongoose.Schema({
    CameraName: String,
    DriverId: { type: Number, get: v => Math.round(v), set: v => Math.round(v) },
    AreaOfIntrest: String,
    IsTriggered: Boolean,
    
});

export default mongoose.model("final",UserSchema,"CameraDB");


