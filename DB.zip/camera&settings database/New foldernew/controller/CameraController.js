import User from "../model/CameraModel.js" 


export const Create=async(req,res)=>{

try{
    const CameraData=new User(req.body);
    const {CameraName}=CameraData;
    const UserExist=await User.findOne({CameraName})
    if(UserExist){
        return res.status(400).json({message:"user already exist"});
    }
    const SavedUser=await CameraData.save();
    res.status(200).json(SavedUser);


}catch(error){
    res.status(500).json({error:"international server error"});
}

}


export const Fetch = async(req,res)=>{
    try{
        const Users = await User.find();
        if(Users.length==0){
            return res.status(404).json({messag:"user not found"});
        }
        res.status(200).json(Users);
       
    }catch(error){
        res.status(500).json({error:"international server error"});
    }
};



export const Update = async(req,res)=>{
    try{
        const id=req.params.id;
        const UserExist = await User.findOne({_id :id});      
        if(!UserExist){
            return res.status(404).json({messag:"user not found"});
        }
        const UpdateUser=await User.findByIdAndUpdate(id,req.body,{new:true})
        res.status(201).json(UpdateUser);
       
    }catch(error){
        res.status(500).json({error:"international server error"});
    }
};


export const DeleteUser = async(req,res)=>{
    try{
        const id=req.params.id;
        const UserExist = await User.findById({_id :id});      
        if(!UserExist){
            return res.status(404).json({messag:"user not found"});
        }
        await User.findByIdAndDelete(id);
        res.status(201).json({message :"user deleted "});
       
    }catch(error){
        res.status(500).json({error:"international server error"});
    }
};
