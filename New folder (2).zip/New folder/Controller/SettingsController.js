import User from "../Model/SettingsModel.js" 

export const CreateSettings=async(req,res)=>{

try{
    const SettingsData=new User(req.body);
    const {FullName}=SettingsData;
    const SettingsExist=await User.findOne({FullName})
    if(SettingsExist){
        return res.status(400).json({message:"user already exist"});
    }
    const SavedSettings=await SettingsData.save();
    res.status(200).json(SavedSettings);


}catch(error){
    res.status(500).json({error:"international server error"});
}

}


export const FetchSettings = async(req,res)=>{
    try{
        const Users = await User.find();
        if(Users.length==0){
            return res.status(404).json({messag:"user not found"});
        }
        res.status(200).json(Users);
       
    }catch(error){
        res.status(500).json({error:"international server error"});
    }
};



export const UpdateSettings = async(req,res)=>{
    try{
        const id=req.params.id;
        const SettingsExist = await User.findOne({_id :id});      
        if(!SettingsExist){
            return res.status(404).json({messag:"user not found"});
        }
        const UpdateUser=await User.findByIdAndUpdate(id,req.body,{new:true})
        res.status(201).json(UpdateUser);
       
    }catch(error){
        res.status(500).json({error:"international server error"});
    }
};


export const DeleteSettings = async(req,res)=>{
    try{
        const id=req.params.id;
        const SettingsExist = await User.findById({_id :id});      
        if(!SettingsExist){
            return res.status(404).json({messag:"user not found"});
        }
        await User.findByIdAndDelete(id);
        res.status(201).json({message :"user deleted "});
       
    }catch(error){
        res.status(500).json({error:"international server error"});
    }
};
