import mongoose from "mongoose";

export const CameraSchema = new mongoose.Schema({
    CameraName: String,
    DriverId: Number,
    AreaOfIntrest: String,
    IsTriggered: Boolean,
}, { versionKey: false });
