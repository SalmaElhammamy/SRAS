import mongoose from "mongoose";

const CameraSchema= new mongoose.Schema({
    CameraName: String,
    DriverId: { type: Number, get: v => Math.round(v), set: v => Math.round(v) },
    AreaOfIntrest: String,
    IsTriggered: Boolean,
    
});

export default mongoose.model("final",CameraSchema,"CameraDB");


