import express from "express"
import mongoose from "mongoose"
import dotenv from "dotenv"
import bodyParser from "body-parser";
import RouteCamera from "./Routes/CameraRoute.js";
import RouteSettings from "./Routes/SettingsRoute.js";
import { CameraSchema } from "./CameraSchema.js";
import { SettingsSchema } from "./SettingsSchema.js";


const app=express();

dotenv.config();

const PORT = process.env.PORT || 8000;
const MONGOURL =process.env.MONGO_URL;
app.use(bodyParser.json());

mongoose.connect(MONGOURL).then(()=>{
    console.log("Database is connected successfully");
    app.listen(PORT, () => {
        console.log(`Server is running on port ${PORT}`);
    });
}).catch((error)=> console.log(error));

const CameraModel = mongoose.model("Cameras",CameraSchema,"CameraDB");


app.get("/getCamera", async (req, res) => {
    try {
        // Execute the query to retrieve user data
        const CameraData = await CameraModel.find();

        // Log the retrieved user data
        console.log("Retrieved user data:", CameraData);

        // Send the retrieved user data as a JSON response
        res.json(CameraData);
    } catch (error) {
        // If an error occurs, log the error and send an error response
        console.error("Error retrieving user data:", error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

app.use("/api/camera",RouteCamera);

export const Create=async(req,res)=>{

    try{
        const CameraData=new User(req.body);
        const {CameraName}=CameraData;
        const UserExist=await User.findOne({CameraName})
        if(UserExist){
            return res.status(400).json({message:"user already exist"});
        }
        const SavedUser=await CameraData.save();
        res.status(200).json/(SavedUser);
    
    
    }catch(error){
        res.status(500).json({error:"international server error"});
    }
    
    }
 



    // SettingsSchema.pre('save', function (next) {
    //     if (!validateTimeFormat(this.ReportFrequency)) {
    //         next(new Error('Invalid ReportFrequency format. Expected format is hh:mm.'));
    //     } else {
    //         next();
    //     }
    // });  
    
    const SettingsModel = mongoose.model("camera",SettingsSchema,"SettingsDB");
    
    
    app.get("/getSettings", async (req, res) => {
        try {
            // Execute the query to retrieve user data
            const SettingsData = await SettingsModel.find();
    
            // Log the retrieved user data
            console.log("Retrieved user data:", SettingsData);
    
            // Send the retrieved user data as a JSON response
            res.json(SettingsData);
        } catch (error) {
            // If an error occurs, log the error and send an error response
            console.error("Error retrieving user data:", error);
            res.status(500).json({ error: 'Internal Server Error' });
        }
    });
    
    app.use("/api/Settings",RouteSettings);
    
    export const Create1=async(req,res)=>{
    
        try{
            const SettingsData=new User(req.body);
            const {FullName}=SettingsData;
            const SettingsExist=await User.findOne({FullName})
            if(SettingsExist){
                return res.status(400).json({message:"user already exist"});
            }
            const SavedSettings=await SettingsData.save();
            res.status(200).json/(SavedSettings);
        
        
        }catch(error){
            res.status(500).json({error:"international server error"});
        }
        
        }
     