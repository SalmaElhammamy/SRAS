import express from "express"
import { FetchCamera,CreateCamera,UpdateCamera,DeleteCamera } from "../Controller/CameraController.js"
// import { Fetch2,Create2,Update2,DeleteUser2 } from "../controller/SettingsController.js"

const CameraRoute=express.Router();

CameraRoute.post("/CreateCamera",CreateCamera);
CameraRoute.get("/GetAllCameras",FetchCamera);
CameraRoute.put("/UpdateCamera/:id", UpdateCamera);
CameraRoute.delete("/DeleteCamera/:id",DeleteCamera);



export default CameraRoute;