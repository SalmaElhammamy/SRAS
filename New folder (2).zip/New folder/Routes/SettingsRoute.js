import express from "express"
import { FetchSettings,CreateSettings,UpdateSettings,DeleteSettings } from "../Controller/SettingsController.js"
// import { Fetch2,Create2,Update2,DeleteUser2 } from "../controller/SettingsController.js"

const RouteSettings=express.Router();

RouteSettings.post("/CreateSettings",CreateSettings);
RouteSettings.get("/GetAllSettings",FetchSettings);
RouteSettings.put("/UpdateSettings/:id", UpdateSettings);
RouteSettings.delete("/DeleteSettings/:id",DeleteSettings);



export default RouteSettings;